Week Planner user files
=======================

The add-on stores its persistent weekly plan in plan.json inside this
folder. Feel free to back it up or place it under version control.
